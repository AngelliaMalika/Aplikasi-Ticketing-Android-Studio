package com.example.ticket

data class HistoryItem(
    val kelas: String,
    val date: String,
    val nama: String,
    val hargaTiket: String,
    val kode1: String,
    val keberangkatan: String,
    val kode2: String,
    val tujuan: String
)
