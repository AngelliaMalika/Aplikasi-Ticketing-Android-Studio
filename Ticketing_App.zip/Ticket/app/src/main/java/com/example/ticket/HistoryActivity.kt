package com.example.ticket

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class HistoryActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var historyAdapter: HistoryAdapter
    private lateinit var historyList: List<HistoryItem>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)

        recyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)

        // Contoh data untuk historyList
        historyList = listOf(
            HistoryItem("Ekonomi", "2024-10-29", "Khaila Oktavianingsih", "Rp 10.000.000", "JKT", "Jakarta", "SMG", "Semarang"),
            // Tambahkan item lain sesuai kebutuhan
        )

        historyAdapter = HistoryAdapter(historyList)
        recyclerView.adapter = historyAdapter
    }
}
