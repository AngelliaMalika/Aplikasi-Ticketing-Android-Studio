package com.example.ticket

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView

class MainActivity : AppCompatActivity() {

    private lateinit var cvPesawat: CardView
    private lateinit var cvKapal: CardView
    private lateinit var cvKereta: CardView
    private lateinit var imageProfile: ImageView
    private lateinit var welcomeTextView: TextView
    private lateinit var searchEditText: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Inisialisasi semua view
        cvPesawat = findViewById(R.id.cvPesawat)
        cvKapal = findViewById(R.id.cvKapal)
        cvKereta = findViewById(R.id.cvKereta)
        imageProfile = findViewById(R.id.imageProfile)
        welcomeTextView = findViewById(R.id.usernameTextView)
        searchEditText = findViewById(R.id.searchEditText) // Inisialisasi EditText

        // Mendapatkan username dari Intent
        val username = intent.getStringExtra("USERNAME")


        // Fungsi pencarian ketika teks berubah
        searchEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                searchTransport(s.toString())
            }

            override fun afterTextChanged(s: Editable?) {}
        })

        // Listener untuk kartu Pesawat
        cvPesawat.setOnClickListener {
            startTransportActivity("Pesawat")
        }

        // Listener untuk kartu Kapal
        cvKapal.setOnClickListener {
            startTransportActivity("Kapal Laut")
        }

        // Listener untuk kartu Kereta
        cvKereta.setOnClickListener {
            startTransportActivity("Kereta")
        }

        // Listener untuk gambar profil
        imageProfile.setOnClickListener {
            startActivity(Intent(this, ProfileActivity::class.java))
        }
    }

    // Fungsi untuk memproses pencarian
    private fun searchTransport(query: String) {
        if (query.isNotEmpty()) {
            Toast.makeText(this, "Mencari: $query", Toast.LENGTH_SHORT).show()
            // Tambahkan logika pencarian atau filter data di sini
        }
    }

    // Fungsi untuk memulai Activity berdasarkan transportasi
    private fun startTransportActivity(transport: String) {
        val intent = Intent(this, InputDataActivity::class.java)
        intent.putExtra("transportasi", transport)
        startActivity(intent)
    }
}
