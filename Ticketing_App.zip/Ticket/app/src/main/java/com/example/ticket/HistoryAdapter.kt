package com.example.ticket

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import android.widget.TextView
import android.widget.ImageView

class HistoryAdapter(private val historyList: List<HistoryItem>) : RecyclerView.Adapter<HistoryAdapter.HistoryViewHolder>() {

    class HistoryViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvKelas: TextView = itemView.findViewById(R.id.tvKelas)
        val tvDate: TextView = itemView.findViewById(R.id.tvDate)
        val tvNama: TextView = itemView.findViewById(R.id.tvNama)
        val tvHargaTiket: TextView = itemView.findViewById(R.id.tvHargaTiket)
        val tvKode1: TextView = itemView.findViewById(R.id.tvKode1)
        val tvKeberangkatan: TextView = itemView.findViewById(R.id.tvKeberangkatan)
        val tvKode2: TextView = itemView.findViewById(R.id.tvKode2)
        val tvTujuan: TextView = itemView.findViewById(R.id.tvTujuan)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HistoryViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.list_item_history, parent, false)
        return HistoryViewHolder(view)
    }

    override fun onBindViewHolder(holder: HistoryViewHolder, position: Int) {
        val historyItem = historyList[position]
        holder.tvKelas.text = historyItem.kelas
        holder.tvDate.text = historyItem.date
        holder.tvNama.text = historyItem.nama
        holder.tvHargaTiket.text = historyItem.hargaTiket
        holder.tvKode1.text = historyItem.kode1
        holder.tvKeberangkatan.text = historyItem.keberangkatan
        holder.tvKode2.text = historyItem.kode2
        holder.tvTujuan.text = historyItem.tujuan
    }

    override fun getItemCount(): Int = historyList.size
}
