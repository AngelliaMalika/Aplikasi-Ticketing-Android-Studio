package com.example.ticket

import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import java.util.*

class InputDataActivity : AppCompatActivity() {

    private lateinit var tvTransportasi: TextView
    private lateinit var tvJmlDewasa: TextView
    private lateinit var tvJmlAnak: TextView
    private lateinit var btnJemputSekarang: MaterialButton
    private lateinit var imageAddDewasa: ImageView
    private lateinit var imageMinusDewasa: ImageView
    private lateinit var imageAddAnak: ImageView
    private lateinit var imageMinusAnak: ImageView
    private lateinit var inputTanggal: TextInputEditText
    private lateinit var spinnerKeberangkatan: Spinner
    private lateinit var spinnerTujuan: Spinner
    private lateinit var spinnerKelas: Spinner

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_input_data)

        // Aktifkan up button
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        // Inisialisasi Views
        tvTransportasi = findViewById(R.id.tvTransportasi)
        tvJmlDewasa = findViewById(R.id.tvJmlDewasa)
        tvJmlAnak = findViewById(R.id.tvJmlAnak)
        btnJemputSekarang = findViewById(R.id.btnCheckout)
        imageAddAnak = findViewById(R.id.imageAdd1)
        imageMinusAnak = findViewById(R.id.imageMinus1)
        imageAddDewasa = findViewById(R.id.imageAdd2)
        imageMinusDewasa = findViewById(R.id.imageMinus2)
        inputTanggal = findViewById(R.id.inputTanggal)

        spinnerKeberangkatan = findViewById(R.id.spBerangkat)
        spinnerTujuan = findViewById(R.id.spTujuan)
        spinnerKelas = findViewById(R.id.spKelas)


        val keberangkatanOptions = arrayOf("Jakarta", "Surabaya", "Semarang", "Bandung")
        val tujuanOptions = arrayOf("Jakarta", "Surabaya", "Semarang", "Bali")
        val kelasOptions = arrayOf("Ekonomi", "Bisnis", "First Class")

        // Mengatur adapter untuk spinner
        val adapterKeberangkatan = ArrayAdapter(this, android.R.layout.simple_spinner_item, keberangkatanOptions)
        val adapterTujuan = ArrayAdapter(this, android.R.layout.simple_spinner_item, tujuanOptions)
        val adapterKelas = ArrayAdapter(this, android.R.layout.simple_spinner_item, kelasOptions)

        adapterKeberangkatan.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        adapterTujuan.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        adapterKelas.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)

        spinnerKeberangkatan.adapter = adapterKeberangkatan
        spinnerTujuan.adapter = adapterTujuan
        spinnerKelas.adapter = adapterKelas

        val transportasi = intent.getStringExtra("transportasi")
        tvTransportasi.text = "Transportasi yang dipilih: $transportasi"


        imageAddDewasa.setOnClickListener {
            val jumlahDewasa = tvJmlDewasa.text.toString().toInt()
            tvJmlDewasa.text = (jumlahDewasa + 1).toString()
        }

        imageMinusDewasa.setOnClickListener {
            val jumlahDewasa = tvJmlDewasa.text.toString().toInt()
            if (jumlahDewasa > 0) {
                tvJmlDewasa.text = (jumlahDewasa - 1).toString()
            }
        }

        imageAddAnak.setOnClickListener {
            val jumlahAnak = tvJmlAnak.text.toString().toInt()
            tvJmlAnak.text = (jumlahAnak + 1).toString()
        }

        imageMinusAnak.setOnClickListener {
            val jumlahAnak = tvJmlAnak.text.toString().toInt()
            if (jumlahAnak > 0) {
                tvJmlAnak.text = (jumlahAnak - 1).toString()
            }
        }


        inputTanggal.setOnClickListener {
            val calendar = Calendar.getInstance()
            val year = calendar.get(Calendar.YEAR)
            val month = calendar.get(Calendar.MONTH)
            val day = calendar.get(Calendar.DAY_OF_MONTH)

            val datePicker = DatePickerDialog(this, { _, year, monthOfYear, dayOfMonth ->
                val selectedDate = "$dayOfMonth/${monthOfYear + 1}/$year"
                inputTanggal.setText(selectedDate)
            }, year, month, day)
            datePicker.show()
        }


        btnJemputSekarang.setOnClickListener {
            val intent = Intent(this, HistoryActivity::class.java)
            startActivity(intent)
        }
    }


    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
}
